package com.ecoagent22;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQUEST_CAMERA = 1001;
    private static final int REQUEST_GALLERY = 1002;

    private LinearLayout list;
    private TextView status;
    private android.content.SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("eco", MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("🚚 Eco Agent 2.2\nمساعد ECOTRACK");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(23, 105, 170));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 12);
        root.addView(title);

        Button access = new Button(this);
        access.setText("⚙️ تفعيل قراءة ECOTRACK");
        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        status = new TextView(this);
        status.setText("صوّر وثيقة الطلب أو اقرأ QR/الباركود.");
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 8, 0, 12);
        root.addView(status);

        Button camera = new Button(this);
        camera.setText("📷 تصوير وثيقة الطلب");
        camera.setOnClickListener(v -> openCamera());
        root.addView(camera);

        Button qr = new Button(this);
        qr.setText("▣ قراءة QR / الباركود");
        qr.setOnClickListener(v -> openCodeScanner());
        root.addView(qr);

        Button gallery = new Button(this);
        gallery.setText("🖼️ اختيار صورة موجودة");
        gallery.setOnClickListener(v -> chooseImage());
        root.addView(gallery);

        Button clear = new Button(this);
        clear.setText("🗑️ مسح آخر نتيجة");
        clear.setOnClickListener(v -> clearResult());
        root.addView(clear);

        TextView resultTitle = new TextView(this);
        resultTitle.setText("النتيجة:");
        resultTitle.setTextSize(18);
        resultTitle.setTextColor(Color.DKGRAY);
        resultTitle.setPadding(0, 16, 0, 8);
        root.addView(resultTitle);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        renderLast();
    }

    private void openCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(intent, REQUEST_CAMERA);
            } else {
                toast("لا توجد كاميرا متاحة.");
            }
        } catch (Exception e) {
            toast("تعذر فتح الكاميرا.");
        }
    }

    private void chooseImage() {
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, REQUEST_GALLERY);
        } catch (Exception e) {
            toast("تعذر فتح معرض الصور.");
        }
    }

    private void openCodeScanner() {
        try {
            com.google.mlkit.vision.codescanner.GmsBarcodeScanner scanner =
                    com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(this);

            scanner.startScan()
                    .addOnSuccessListener(barcode -> {
                        String value = barcode.getRawValue();
                        if (value == null) value = "";
                        saveResult("QR / الباركود", value);
                        status.setText("تمت قراءة الكود بنجاح.");
                        toast("تمت قراءة الكود.");
                    })
                    .addOnCanceledListener(() ->
                            status.setText("تم إلغاء قراءة QR."))
                    .addOnFailureListener(e -> {
                        status.setText("تعذر تشغيل قارئ QR.");
                        toast("تعذر تشغيل قارئ QR.");
                    });
        } catch (Exception e) {
            status.setText("قارئ QR غير متاح.");
            toast("قارئ QR غير متاح.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        try {
            Bitmap bitmap = null;

            if (requestCode == REQUEST_CAMERA && data.getExtras() != null) {
                Object x = data.getExtras().get("data");
                if (x instanceof Bitmap) bitmap = (Bitmap) x;
            } else if (requestCode == REQUEST_GALLERY && data.getData() != null) {
                bitmap = MediaStore.Images.Media.getBitmap(
                        getContentResolver(), data.getData());
            }

            if (bitmap == null) {
                toast("لم أستطع الحصول على الصورة.");
                return;
            }

            runOcr(bitmap);
        } catch (Exception e) {
            status.setText("تعذر فتح الصورة.");
            toast("حدث خطأ أثناء فتح الصورة.");
        }
    }

    private void runOcr(Bitmap bitmap) {
        status.setText("جارٍ تحليل الصورة...");

        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            com.google.mlkit.vision.text.TextRecognizer recognizer =
                    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        String text = result.getText();
                        if (text == null) text = "";
                        text = text.trim();

                        if (text.isEmpty()) {
                            status.setText("لم أجد نصًا واضحًا. صوّر الوثيقة أقرب وأوضح.");
                            return;
                        }

                        saveResult("قراءة الصورة", parseOrder(text));
                        status.setText("تمت قراءة الصورة بنجاح.");
                    })
                    .addOnFailureListener(e -> {
                        status.setText("تعذر تحليل الصورة.");
                        toast("فشل OCR.");
                    })
                    .addOnCompleteListener(task -> recognizer.close());
        } catch (Exception e) {
            status.setText("تعذر بدء تحليل الصورة.");
            toast("حدث خطأ في OCR.");
        }
    }

    private String parseOrder(String text) {
        LinkedHashMap<String, String> data = new LinkedHashMap<>();

        put(data, "الهاتف", first(text, "0[5-7][0-9]{8}"));
        put(data, "رقم التتبع", after(text, "رقم التتبع"));
        put(data, "رمز الطلبية", after(text, "رمز الطلبية"));
        put(data, "السعر الإجمالي", after(text, "السعر الإجمالي"));
        put(data, "العنوان", after(text, "العنوان"));
        put(data, "المدينة", after(text, "المدينة"));

        StringBuilder out = new StringBuilder();
        for (Map.Entry<String, String> e : data.entrySet()) {
            out.append("• ").append(e.getKey()).append(" : ")
                    .append(e.getValue()).append("\n");
        }

        out.append("\nالنص المستخرج:\n").append(text);
        return out.toString();
    }

    private void saveResult(String title, String value) {
        if (value == null) value = "";

        String phone = first(value, "0[5-7][0-9]{8}");
        String address = after(value, "العنوان");
        String city = after(value, "المدينة");

        prefs.edit()
                .putString("last_order", "【" + title + "】\n" + value)
                .putString("phone", phone == null ? "" : phone)
                .putString("address", address == null ? "" : address)
                .putString("city", city == null ? "" : city)
                .apply();

        renderLast();
    }

    private void renderLast() {
        if (list == null || prefs == null) return;
        list.removeAllViews();

        String data = prefs.getString("last_order", "");
        if (data.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("\nلا يوجد طلب مقروء بعد.");
            t.setTextSize(17);
            list.addView(t);
            return;
        }

        TextView t = new TextView(this);
        t.setText("\nآخر طلب:\n\n" + data);
        t.setTextSize(17);
        t.setTextColor(Color.DKGRAY);
        list.addView(t);

        String phone = prefs.getString("phone", "");
        Button sms = new Button(this);
        sms.setText("✉️ فتح SMS");
        sms.setOnClickListener(v -> {
            if (phone.isEmpty()) {
                toast("لم يتم العثور على رقم الهاتف.");
                return;
            }
            String msg = "السلام عليكم، معك عامل التوصيل. من فضلك أرسل لي موقعك الحالي عبر رابط Google Maps لتسهيل التوصيل. شكراً.";
            startActivity(new Intent(Intent.ACTION_SENDTO,
                    Uri.parse("smsto:" + Uri.encode(phone)))
                    .putExtra("sms_body", msg));
        });
        list.addView(sms);

        String address = prefs.getString("address", "");
        String city = prefs.getString("city", "");
        Button map = new Button(this);
        map.setText("📍 فتح العنوان في Google Maps");
        map.setOnClickListener(v -> {
            String q = (address + " " + city).trim();
            if (q.isEmpty()) {
                toast("لا يوجد عنوان.");
                return;
            }
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(q))));
        });
        list.addView(map);
    }

    private void clearResult() {
        prefs.edit().clear().apply();
        renderLast();
        status.setText("تم مسح آخر نتيجة.");
        toast("تم مسح النتيجة.");
    }

    private void put(Map<String, String> map, String key, String value) {
        if (value != null && !value.trim().isEmpty()) map.put(key, value.trim());
    }

    private String first(String text, String regex) {
        if (text == null) return null;
        try {
            Matcher m = Pattern.compile(regex).matcher(text);
            return m.find() ? m.group() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String after(String text, String label) {
        if (text == null || label == null) return null;
        try {
            Matcher m = Pattern.compile(
                    Pattern.quote(label) + "\\s*[:：]?\\s*([^\\n]+)"
            ).matcher(text);
            return m.find() ? m.group(1).trim() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs != null) renderLast();
    }
}
