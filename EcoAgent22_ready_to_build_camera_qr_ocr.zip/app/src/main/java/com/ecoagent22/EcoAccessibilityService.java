package com.ecoagent22;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.WindowManager;
import android.view.Gravity;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.Toast;
import java.util.*;
import java.util.regex.*;

public class EcoAccessibilityService extends AccessibilityService {
    WindowManager wm;
    Button floating;

    @Override public void onServiceConnected() {
        AccessibilityServiceInfo i=getServiceInfo();
        i.packageNames=new String[]{"com.ecotrackdz.driver_app"};
        i.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(i);
        showButton();
    }

    void showButton() {
        if(floating!=null) return;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        floating=new Button(this);
        floating.setText("قراءة\nالطلب");
        floating.setTextColor(Color.WHITE);
        GradientDrawable g=new GradientDrawable();
        g.setColor(Color.rgb(23,105,170));
        g.setCornerRadius(80);
        floating.setBackground(g);
        floating.setOnClickListener(v->readOrder());

        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
            180,110,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;
        p.x=12; p.y=0;
        wm.addView(floating,p);
    }

    void readOrder() {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null){toast("لم أستطع قراءة شاشة ECOTRACK.");return;}
        ArrayList<String> n=new ArrayList<>();
        collect(root,n);

        // Keep unique visible strings in their accessibility order.
        LinkedHashSet<String> u=new LinkedHashSet<>(n);
        n=new ArrayList<>(u);

        String all=String.join("\n",n);
        Map<String,String> m=new LinkedHashMap<>();

        String[] labels={"المرسل","رقم التتبع","رمز الطلبية","رمز الطلب","نوع العملية","المرسل إليه","الولاية","البلدية","العنوان","الهاتف","السعر الإجمالي","التاريخ"};
        for(int i=0;i<n.size();i++){
            String x=n.get(i);
            for(String label:labels){
                if(x.equals(label) || x.contains(label)){
                    String v=neighbor(n,i,labels);
                    if(v!=null && !m.containsKey(label)) m.put(label,v);
                }
            }
        }

        put(m,"الهاتف", first(all,"0[5-7][0-9]{8}"));
        put(m,"السعر الإجمالي", after(all,"السعر الإجمالي"));
        put(m,"رقم التتبع", after(all,"رقم التتبع"));

        // Common screen order from the supplied ECOTRACK layout:
        // value may appear before label because of RTL accessibility traversal.
        if(!m.containsKey("الولاية")) put(m,"الولاية", valueNear(n,"الولاية",1));
        if(!m.containsKey("البلدية")) put(m,"البلدية", valueNear(n,"البلدية",1));
        if(!m.containsKey("العنوان")) put(m,"العنوان", valueNear(n,"العنوان",1));

        StringBuilder out=new StringBuilder();
        for(Map.Entry<String,String> e:m.entrySet())
            out.append("• ").append(e.getKey()).append(" : ").append(e.getValue()).append("\n");

        if(out.length()==0) out.append("النص الذي سمح ECOTRACK بقراءته:\n").append(all);

        getSharedPreferences("eco",MODE_PRIVATE).edit()
            .putString("last_order",out.toString())
            .putString("phone",m.getOrDefault("الهاتف",""))
            .putString("city",m.getOrDefault("البلدية",m.getOrDefault("الولاية","")))
            .putString("address",m.getOrDefault("العنوان",""))
            .apply();

        toast(out.length()>20 ? "تمت قراءة الطلب. افتح Eco Agent لرؤية النتيجة." : "لم أجد بيانات قابلة للقراءة.");
    }

    void collect(AccessibilityNodeInfo n,ArrayList<String> out){
        if(n==null)return;
        CharSequence t=n.getText();
        if(t!=null && t.toString().trim().length()>0) out.add(t.toString().trim());
        for(int i=0;i<n.getChildCount();i++) collect(n.getChild(i),out);
    }

    String neighbor(ArrayList<String> n,int i,String[] labels){
        // Try the next few nodes, then previous few for RTL traversal.
        for(int d=1;d<=3;d++){
            int j=i+d;
            if(j<n.size() && validValue(n.get(j),labels)) return n.get(j);
        }
        for(int d=1;d<=3;d++){
            int j=i-d;
            if(j>=0 && validValue(n.get(j),labels)) return n.get(j);
        }
        return null;
    }

    boolean validValue(String s,String[] labels){
        if(s==null || s.trim().isEmpty())return false;
        for(String x:labels) if(s.equals(x)) return false;
        return true;
    }

    String valueNear(ArrayList<String> n,String label,int distance){
        int i=n.indexOf(label);
        if(i<0)return null;
        return neighbor(n,i,new String[]{label});
    }

    void put(Map<String,String> m,String k,String v){ if(!m.containsKey(k)&&v!=null&&!v.isEmpty())m.put(k,v); }

    String first(String s,String re){
        Matcher m=Pattern.compile(re).matcher(s);
        return m.find()?m.group():null;
    }

    String after(String s,String label){
        Pattern p=Pattern.compile(Pattern.quote(label)+"\\s*[:：]?\\s*([^\\n]+)");
        Matcher m=p.matcher(s);
        return m.find()?m.group(1).trim():null;
    }

    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e){}
    @Override public void onInterrupt(){}
}
