package com.ecoagent22;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list;
    TextView status;
    android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("eco", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("🚚 Eco Agent 2.2\nمساعد ECOTRACK");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(23,105,170));
        root.addView(title);

        Button access = new Button(this);
        access.setText("⚙️ تفعيل قراءة ECOTRACK");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        status = new TextView(this);
        status.setText("افتح ECOTRACK ثم استعمل زر «قراءة الطلب» العائم.");
        status.setTextSize(16);
        root.addView(status);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        setContentView(root);
        renderLast();
    }

    void renderLast() {
        list.removeAllViews();
        String data = prefs.getString("last_order","");
        if(data.isEmpty()) {
            TextView t=new TextView(this);
            t.setText("\nلا يوجد طلب مقروء بعد.");
            t.setTextSize(17);
            list.addView(t);
            return;
        }

        TextView t=new TextView(this);
        t.setText("\nآخر طلب:\n"+data);
        t.setTextSize(17);
        list.addView(t);

        String phone = prefs.getString("phone","");
        Button sms = new Button(this);
        sms.setText("✉️ فتح SMS");
        sms.setOnClickListener(v -> {
            if(phone.isEmpty()) { Toast.makeText(this,"لم يتم العثور على رقم الهاتف.",Toast.LENGTH_SHORT).show(); return; }
            String msg="السلام عليكم، معك عامل التوصيل. من فضلك أرسل لي موقعك الحالي عبر رابط Google Maps لتسهيل التوصيل. شكراً.";
            startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+Uri.encode(phone)))
                    .putExtra("sms_body", msg));
        });
        list.addView(sms);

        String address = prefs.getString("address","");
        String city = prefs.getString("city","");
        Button map = new Button(this);
        map.setText("📍 فتح العنوان في Google Maps");
        map.setOnClickListener(v -> {
            String q=(address+" "+city).trim();
            if(q.isEmpty()) { Toast.makeText(this,"لا يوجد عنوان.",Toast.LENGTH_SHORT).show(); return; }
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query="+Uri.encode(q))));
        });
        list.addView(map);
    }

    @Override protected void onResume() {
        super.onResume();
        if(prefs!=null) renderLast();
    }
}
